<?php 
include "header.html";
include "navbar.html";
include "body.html";
include "footer.html";



 ?>


